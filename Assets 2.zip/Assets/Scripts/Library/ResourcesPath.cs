﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourcesPath : MonoBehaviour
{
    public static string SpriteFolderPath = "Sprites/";

	public static string CSV_FolderFath = "CSV/";
	public static string CSV_Dialog = "Dialog";
}
