﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourcesPath : MonoBehaviour
{
    public static string FolderPath = "A/";

    public static string A = FolderPath + "A";
}
