﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class CustomMenu : MonoBehaviour
{
	private static string PrefabPath = "ReservedPrefabs/";

	[MenuItem("JNE/UI/Popup &_s")]
	public static void MakePrefab()
	{
		GameObject selectedObj = Selection.activeGameObject;

		GameObject copy = GameObject.Instantiate (Resources.Load(PrefabPath + "Popup"), selectedObj.transform) as GameObject;

		if(selectedObj != null)
		{
			copy.transform.SetParent (selectedObj.transform);
		}

		copy.name = "Popup";
	}
}
