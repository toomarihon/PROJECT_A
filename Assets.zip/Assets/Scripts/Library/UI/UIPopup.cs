﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIPopup : MonoBehaviour 
{
	public enum POPUP_TYPE
	{
		NONE = -1,
		FULLSCREEN,
		POPUP,
		SYSTEM,
	}

	public enum POPUP_STYLE
	{
		NONE = -1,
		DYNAMIC,
	}

	public enum POPUP_STATE
	{
		NONE = -1,
		START_OPEN,
		OPEN,
		START_CLOSE,
	}
		
	public POPUP_TYPE _curPopupType = POPUP_TYPE.POPUP;
	public POPUP_STYLE _curPopupStyle = POPUP_STYLE.DYNAMIC;

	public AnimationCurve[] _openTransitionScaleCurve;
	public IEnumerator _transitionCoroutine;

	private POPUP_STATE _curPopupState = POPUP_STATE.START_OPEN;
	private float _curTransitionTime;
	private float _maxTransitionTime;
	private 

	public void OpenPopup()
	{
		this.transform.localScale = Vector3.zero;
		_curTransitionTime = 0;
		_maxTransitionTime = _openTransitionScaleCurve [(int)_curPopupStyle].keys[_openTransitionScaleCurve[(int)_curPopupStyle].length - 1].time;
		Debug.Log ("MAX : " + _maxTransitionTime);
		_curPopupState = POPUP_STATE.START_OPEN;
	}
		
	public void OnEnable()
	{
		OpenPopup ();
	}

	public void Update()
	{
		PopupState ();
	}

	public void PopupState()
	{
		if(_curPopupState == POPUP_STATE.OPEN)
		{
			return;
		}
		
		switch(_curPopupState)
		{
		case POPUP_STATE.START_OPEN:
			State_StartOpen ();
			break;
		case POPUP_STATE.START_CLOSE:
			State_CloseOpen ();
			break;
		}
	}

	public void State_StartOpen()
	{
		_curTransitionTime += Time.deltaTime;
		AnimationCurve animCurve = _openTransitionScaleCurve [(int)_curPopupStyle];

		float scale = animCurve.Evaluate (_curTransitionTime);
		this.transform.localScale = new Vector3 (scale, scale, scale);

		if(_curTransitionTime >= _maxTransitionTime)
		{
			_curTransitionTime = _maxTransitionTime;
			_curPopupState = POPUP_STATE.OPEN;
		}
	}

	public void State_CloseOpen()
	{
		_curTransitionTime -= Time.deltaTime;
		AnimationCurve animCurve = _openTransitionScaleCurve [(int)_curPopupStyle];

		float scale = animCurve.Evaluate (_curTransitionTime);
		this.transform.localScale = new Vector3 (scale, scale, scale);

		if(_curTransitionTime <= 0)
		{
			_curTransitionTime = 0;
			_curPopupState = POPUP_STATE.NONE;
		}
	}

	public void StopTransition()
	{
		if(_transitionCoroutine != null)
		{
			StopCoroutine (_transitionCoroutine);
			_transitionCoroutine = null;
		}
	}
}
