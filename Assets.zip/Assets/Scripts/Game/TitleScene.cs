﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleScene : MonoBehaviour 
{
	public GameObject[] _testPopup;
	int idx = 0;

	public void PushPopupButton()
	{
		PanelStackManager.Instance.Push (PanelStackManager.PopupName.TEST);
	}

	public void PopPopupButton()
	{
		idx--;
		PanelStackManager.Instance.Pop();
	}
}
